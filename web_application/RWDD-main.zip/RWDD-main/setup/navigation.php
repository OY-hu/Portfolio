<!-- 
This file contains the HTML code for the header UI.
This file also contains the PHP code to determine the options in the header.
-->

<?php
    include __DIR__.'/../setup/connect.php';

    $role = $_SESSION['role'];
    switch ($role) {
        case "Admin":
            $navigation = ["User<br/>Management", "Student<br/>Monitoring", "Media<br/>Monitoring", "Help<br/>Desk"];
            break;
        case "Vendor":
            $navigation = ["Quest<br/>Management", "Community", "Marketplace", "Help<br/>Desk"];
            break;
        case "Student":
            $navigation = ["Quest", "Community", "Marketplace", "Help Desk"];
            break;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/layout.css" />
    <link rel="stylesheet" href="../setup/navigation.css" />
</head>

<script>
    function openMenu() {
        document.getElementById("logo").classList.toggle("open");
        document.getElementById("navigation").classList.toggle("open");
        document.getElementById("userNav").classList.toggle("open");
        document.getElementById("menu").classList.toggle("open");
        document.getElementById("menuButton").classList.toggle("open");
    }
</script>

<body>
    <button id="menuButton" onclick="openMenu()">&#9776;</button><br />
    <div id="menu">
        <img id="logo" src="../setup/icon/logo.png"/>

        <div id="navigation">
            <ul>
                <?php
                    foreach ($navigation as $nav) {
                        echo "<li>$nav</li>";
                    }
                ?>
            </ul>
        </div>
        
        <?php if ($role == "Student") { 
            $accountID = $_SESSION['accountID'];
            $sql = "SELECT studentID FROM student WHERE accountID = '$accountID'";
            $statement = mysqli_query($connect, $sql);
            $result = mysqli_fetch_array($statement);
            $studentID = $result['studentID'];

            $sql = "SELECT COUNT(points) AS total FROM history WHERE studentID = '$studentID'";
            $statement = mysqli_query($connect, $sql);
            $result = mysqli_fetch_array($statement);
            $points = $result['total'];

            echo "
            <div id='userPoints'>
                <img id='pointIcon' src='../setup/icon/leaf.png' />
                <label id='points'>$points</label>
            </div>";
        } ?>

        <div id="userNav">
            <ul>
                <li><a href="../setup/signOut.php"><img id="logout" src="../setup/icon/logout.png" /></a></li>
                <li><a href="#"><img id="profile" src="../setup/icon/profile.png" /></a></li>
            </ul>
        </div>
    </div>
    <br />
</body>
</html>